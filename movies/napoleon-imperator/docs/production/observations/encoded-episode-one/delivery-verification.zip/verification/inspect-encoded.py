"""Inspect an explicit completed encode into a separate immutable follow-up folder."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,uuid
import numpy as np
from PIL import Image,ImageDraw
import soundfile as sf
FFMPEG=Path('D:/github/samchon/.automovie-runtime/voxcpm/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe')
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',required=True,type=Path);parser.add_argument('--probe',required=True,type=Path);args=parser.parse_args()
run=args.run.resolve();probe=args.probe.resolve()
if run.parent!=ROOT/'public/outputs/episode-one/runs':raise ValueError('Explicit owned run required')
complete=json.loads((run/'completed.json').read_text(encoding='utf-8'));baseline=json.loads((run/'baseline.json').read_text(encoding='utf-8'))
if not complete['completed'] or complete['mode']!='complete-capture' or (run/'failed.json').exists():raise ValueError('Successful complete encode required')
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
for record in complete['outputs']:
    file=run/record['path']
    if file.stat().st_size!=record['bytes'] or sha(file)!=record['sha256']:raise ValueError(f'Changed capture output {file}')
film=json.loads((ROOT/'public/film.json').read_text(encoding='utf-8'))
if sha(ROOT/'public/film.json')!=complete['filmSha256']:raise ValueError('Film changed')
verification=ROOT/'public/outputs/episode-one/verification'/f'{run.name}-{uuid.uuid4().hex[:8]}'
verification.mkdir(parents=True,exist_ok=False)
movie=run/'the-road-gives-way.mp4'
command=[str(FFMPEG),'-hide_banner','-nostdin','-xerror','-err_detect','explode','-v','info','-i',str(movie),'-map','0:v:0','-map','0:a:0','-progress','pipe:1','-f','null','NUL']
decode=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
(verification/'decode.log').write_text(decode.stderr,encoding='utf-8');(verification/'decode-progress.log').write_text(decode.stdout,encoding='utf-8')
frames=[int(n) for n in re.findall(r'^frame=(\d+)$',decode.stdout,re.M)]
if decode.returncode or not frames or frames[-1]!=film['frames'] or 'progress=end' not in decode.stdout:raise ValueError('Whole video/audio decode failed')
# Decode the actual delivered track for its measured extent, not a listening verdict.
audio=subprocess.run([str(FFMPEG),'-hide_banner','-nostdin','-i',str(movie),'-map','0:a:0','-c:a','pcm_s16le',str(verification/'decoded-audio.wav')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
(verification/'audio-decode.log').write_text(audio.stderr,encoding='utf-8')
if audio.returncode:raise ValueError('Delivered audio decode failed')
delivered,rate=sf.read(verification/'decoded-audio.wav');source,_=sf.read(ROOT/'public/audio/001-road/episode-mix.wav')
common=min(len(delivered),len(source));delta=delivered[:common]-source[:common]
audio_metrics={'frames':len(delivered),'sampleRate':rate,'channels':delivered.shape[1],'duration':len(delivered)/rate,'peak':float(np.max(np.abs(delivered))),'sourceFrames':len(source),'frameDifference':len(delivered)-len(source),'differenceRms':float(np.sqrt(np.mean(delta**2))),'acceptance':'unheard'}
# Extract every encoded entry/middle/exit frame corresponding to the original complete probe.
samples=[]
for shot in film['shots']:
    for label,local in [('entry',0),('middle',min(4,shot['duration']/2)),('exit',shot['duration']-1/film['fps'])]:
        frame=round((shot['start']+local)*film['fps']);samples.append({'shot':shot['id'],'sample':label,'frame':frame,'time':frame/film['fps'],'source':f"probe-{shot['id']}-{label}.png"})
ordered=sorted({sample['frame'] for sample in samples});images=verification/'encoded-frames';images.mkdir()
expression='+'.join(f'eq(n,{frame})' for frame in ordered)
extract=subprocess.run([str(FFMPEG),'-hide_banner','-nostdin','-i',str(movie),'-an','-vf',f"select='{expression}'",'-fps_mode','vfr',str(images/'%04d.png')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
(verification/'extract.log').write_text(extract.stderr,encoding='utf-8')
if extract.returncode or len(list(images.glob('*.png')))!=len(ordered):raise ValueError('Incomplete encoded sample population')
for sample in samples:
    file=images/f"{ordered.index(sample['frame'])+1:04d}.png";decoded=np.array(Image.open(file).convert('RGB'),dtype=np.float64);original=np.array(Image.open(probe/sample['source']).convert('RGB'),dtype=np.float64)
    if decoded.shape!=original.shape:raise ValueError('Encoded dimensions changed')
    error=decoded-original;sample.update({'file':file.relative_to(verification).as_posix(),'sha256':sha(file),'mae':float(np.mean(np.abs(error))),'rmse':float(np.sqrt(np.mean(error**2)))})
# Separate sheets preserve exact decoded files and their mapping.
for label in ['entry','middle','exit']:
    subset=[s for s in samples if s['sample']==label]
    for offset in range(0,len(subset),12):
        sheet=Image.new('RGB',(1280,820),'#111722');draw=ImageDraw.Draw(sheet)
        for i,sample in enumerate(subset[offset:offset+12]):
            x,y=i%3*426,i//3*205;image=Image.open(verification/sample['file']).convert('RGB');image.thumbnail((420,176));sheet.paste(image,(x,y+24));draw.text((x+8,y+5),f"{sample['time']:.2f}s | {sample['shot']} | encoded {label}",fill='#eee0c6')
        sheet.save(verification/f"{label}-sheet-{offset//12+1}.jpg",quality=93)
receipt={'schemaVersion':1,'kind':'encoded-artifact-verification','captureRun':run.name,'runtimeIdentity':complete['runtimeIdentity'],'completedSha256':sha(run/'completed.json'),'movie':{'file':str(movie),'bytes':movie.stat().st_size,'sha256':sha(movie)},'decode':{'exitCode':decode.returncode,'videoFrames':frames[-1],'progressEnd':True},'audio':audio_metrics,'samples':samples,'scope':'Complete decoded video/audio extent and encoded sampled-image comparison; no continuous audience viewing or listening acceptance'}
(verification/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'verification':str(verification),'movie':receipt['movie'],'decode':receipt['decode'],'audio':audio_metrics,'samples':len(samples),'worstRmse':max(s['rmse'] for s in samples)},ensure_ascii=False))


