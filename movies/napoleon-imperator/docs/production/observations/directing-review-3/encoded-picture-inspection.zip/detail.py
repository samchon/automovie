import hashlib
import json
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parent
movie = root.parent / 'runs/2026-10-30T05-39-06-671Z-883b5595c1fe-da92a05b/the-road-gives-way.mp4'
ffmpeg = Path('D:/github/samchon/.automovie-runtime/voxcpm/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe')
ranges = [('challenge',84,93,4), ('cannon',251.5,252.5,1), ('guard',277,284,4), ('ice',316,320,4), ('bowl',333,337,4), ('straw',350,353.5,2)]
samples = [(n, label) for label, start, end, stride in ranges for n in range(round(start*24), round(end*24)+1, stride)]
expression = '+'.join(f'eq(n\\,{n})' for n, _ in samples)
command = [str(ffmpeg), '-v', 'error', '-i', str(movie), '-an', '-vf', f'select={expression},scale=480:270', '-fps_mode', 'passthrough', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-']
width, height = 480,270
images = []
with (root / 'detail-decode.log').open('wb') as log:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=log)
    while True:
        data = process.stdout.read(width * height * 3)
        if not data:
            break
        if len(data) != width * height * 3:
            raise RuntimeError('Incomplete image')
        images.append(Image.frombytes('RGB', (width,height), data))
    if process.wait() != 0 or len(images) != len(samples):
        raise RuntimeError('Decode count or exit failure')
font = ImageFont.truetype('C:/Windows/Fonts/consola.ttf',18)
records = []
for start in range(0,len(images),16):
    sheet=Image.new('RGB',(width*4,(height+28)*4),'#101721')
    draw=ImageDraw.Draw(sheet)
    for offset, frame in enumerate(images[start:start+16]):
        n,label=samples[start+offset]
        x,y=(offset%4)*width,(offset//4)*(height+28)
        draw.text((x+4,y+4),f'{n/24:.4f}s {label} | {n}',font=font,fill='white')
        sheet.paste(frame,(x,y+28))
    name=f'detail-{start//16+1:02}.jpg'
    sheet.save(root/name,quality=93)
    records.append({'file':name,'samples':samples[start:start+16],'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()})
(root/'detail-receipt.json').write_text(json.dumps({'movieSha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'ranges':ranges,'samples':len(images),'command':command,'sheets':records},indent=2),encoding='utf-8')
print(json.dumps({'samples':len(images),'sheets':len(records)}))
