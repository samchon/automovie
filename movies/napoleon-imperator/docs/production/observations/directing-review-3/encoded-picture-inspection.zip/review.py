import hashlib
import json
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parent
movie = root.parent / 'runs/2026-10-30T05-39-06-671Z-883b5595c1fe-da92a05b/the-road-gives-way.mp4'
ffmpeg = Path('D:/github/samchon/.automovie-runtime/voxcpm/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe')
width, height, stride = 384, 216, 12
command = [str(ffmpeg), '-v', 'error', '-i', str(movie), '-an', '-vf', 'select=not(mod(n\\,12)),scale=384:216', '-fps_mode', 'passthrough', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-']
images = []
with (root / 'decode.log').open('wb') as log:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=log)
    while True:
        data = process.stdout.read(width * height * 3)
        if not data:
            break
        if len(data) != width * height * 3:
            raise RuntimeError('Incomplete decoded image')
        images.append(Image.frombytes('RGB', (width, height), data))
    if process.wait() != 0:
        raise RuntimeError('Decode failed; inspect decode.log')
font = ImageFont.truetype('C:/Windows/Fonts/consola.ttf', 17)
records = []
for start in range(0, len(images), 24):
    sheet = Image.new('RGB', (width * 4, (height + 26) * 6), '#101721')
    draw = ImageDraw.Draw(sheet)
    for offset, frame in enumerate(images[start:start + 24]):
        index = (start + offset) * stride
        x, y = (offset % 4) * width, (offset // 4) * (height + 26)
        draw.text((x + 5, y + 3), f'{index / 24:07.3f}s | frame {index}', font=font, fill='white')
        sheet.paste(frame, (x, y + 26))
    name = f'timeline-{start // 24 + 1:02}.jpg'
    sheet.save(root / name, quality=92)
    records.append({'file': name, 'firstFrame': start * stride, 'lastFrame': (start + len(images[start:start + 24]) - 1) * stride, 'sha256': hashlib.sha256((root / name).read_bytes()).hexdigest()})
receipt = {'movie': str(movie), 'sha256': hashlib.sha256(movie.read_bytes()).hexdigest(), 'fps': 24, 'sampling': 'Decoded source frames 0,12,...,9216; every 0.5 seconds, not continuous viewing or hearing', 'decodedSamples': len(images), 'command': command, 'sheets': records}
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps({'samples': len(images), 'sheets': len(records), 'movieSha256': receipt['sha256']}))
